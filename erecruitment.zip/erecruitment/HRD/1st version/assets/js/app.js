/* Boot: sidebar, topbar role switcher, reset, router start. */
(function (global) {
  'use strict';

  var ERec = global.ERec = global.ERec || {};
  var store = ERec.store, ui = ERec.ui, fmt = ERec.fmt;

  function navItems() {
    var me = store.actingUser();
    var pending = store.pendingApprovalsFor(me.id).length;
    var items = [
      { name: 'dashboard', href: '#/', icon: 'bi-speedometer2', label: 'Dashboard' },
      { name: 'circulars', href: '#/circulars', icon: 'bi-megaphone', label: 'Circulars' },
      { name: 'approvals', href: '#/approvals', icon: 'bi-inbox', label: 'Approvals', badge: pending || 0 },
      { name: 'outbox', href: '#/outbox', icon: 'bi-envelope-paper', label: 'Mail / SMS Outbox' }
    ];
    return items;
  }

  function renderNav() {
    var el = document.getElementById('sidebar-nav');
    if (!el) return;
    var cur = ERec.router.current();

    var html = navItems().map(function (it) {
      return '<a class="nav-link-x' + (cur.name === it.name ? ' active' : '') + '" href="' + it.href + '" data-nav="' + it.name + '">' +
        '<i class="bi ' + it.icon + '"></i><span>' + it.label + '</span>' +
        (it.badge ? '<span class="badge rounded-pill text-bg-danger">' + it.badge + '</span>' : '') +
        '</a>';
    }).join('');

    html += '<div class="nav-section">Active circulars</div>';
    store.where('circulars', function (c) { return c.status === 'ACTIVE'; }).forEach(function (c) {
      var active = cur.params && cur.params.cid === c.id;
      var p = ERec.pipeline.circularProgress(c.id);
      html += '<a class="nav-link-x' + (active ? ' active' : '') + '" href="#/circular/' + c.id + '" title="' + fmt.esc(c.title) + '">' +
        '<i class="bi bi-briefcase"></i>' +
        '<span class="text-truncate">' + fmt.esc(c.post) + '</span>' +
        '<span class="badge rounded-pill text-bg-secondary">' + p.pct + '%</span>' +
        '</a>';
    });

    el.innerHTML = html;
  }

  function renderTopbar() {
    var el = document.getElementById('topbar-right');
    if (!el) return;
    var me = store.actingUser();
    var users = store.all('users');
    var pending = store.pendingApprovalsFor(me.id).length;

    el.innerHTML =
      (me.role === 'APPROVER'
        ? '<a href="#/approvals" class="btn btn-sm btn-outline-primary btn-icon"><i class="bi bi-inbox"></i> Approval inbox' +
          (pending ? ' <span class="badge rounded-pill text-bg-danger">' + pending + '</span>' : '') + '</a>'
        : '') +
      '<div class="dropdown">' +
        '<div class="acting-chip" data-bs-toggle="dropdown" role="button">' +
          ui.avatar(me.name, me.role === 'HR_ADMIN' ? 'primary' : '') +
          '<span class="d-none d-md-flex flex-column lh-sm text-start">' +
            '<span class="fw-semibold" style="font-size:12.5px">' + fmt.esc(me.name) + '</span>' +
            '<span class="muted" style="font-size:10.5px">' + fmt.esc(me.role === 'HR_ADMIN' ? 'HR Admin' : 'Approver') + '</span>' +
          '</span>' +
          '<i class="bi bi-chevron-down muted" style="font-size:11px"></i>' +
        '</div>' +
        '<ul class="dropdown-menu dropdown-menu-end shadow-sm" style="min-width:280px">' +
          '<li><h6 class="dropdown-header">Acting as</h6></li>' +
          users.map(function (u) {
            var np = store.pendingApprovalsFor(u.id).length;
            return '<li><a class="dropdown-item d-flex align-items-center gap-2 ' + (u.id === me.id ? 'active' : '') + '" href="#" data-user="' + u.id + '">' +
              ui.avatar(u.name, 'sm') +
              '<span class="flex-grow-1"><span class="d-block fw-semibold" style="font-size:12.5px">' + fmt.esc(u.name) + '</span>' +
              '<span class="d-block" style="font-size:11px;opacity:.75">' + fmt.esc(u.designation) + '</span></span>' +
              (np ? '<span class="badge rounded-pill text-bg-danger">' + np + '</span>' : '') +
              '</a></li>';
          }).join('') +
          '<li><hr class="dropdown-divider"></li>' +
          '<li><span class="dropdown-item-text fs-12 muted">Switch role to approve requests that were sent for approval.</span></li>' +
        '</ul>' +
      '</div>';

    el.querySelectorAll('[data-user]').forEach(function (a) {
      a.addEventListener('click', function (e) {
        e.preventDefault();
        store.setActingUser(a.dataset.user);
        var u = store.find('users', a.dataset.user);
        ui.toast('Now acting as ' + u.name);
        renderAll();
      });
    });
  }

  function renderAll() {
    renderNav();
    renderTopbar();
    ERec.router.refresh();
  }

  function syncNav() {
    renderNav();
    renderTopbar();
  }

  function storageNote() {
    var el = document.getElementById('storage-note');
    if (!el) return;
    el.innerHTML = store.storageAvailable()
      ? '<i class="bi bi-hdd"></i> Saved in this browser'
      : '<i class="bi bi-exclamation-triangle"></i> Browser storage blocked — changes last until you refresh';
  }

  function boot() {
    store.load();

    document.getElementById('btn-reset-demo').addEventListener('click', function () {
      ui.confirm({
        title: 'Reset demo data',
        body: 'This restores the three seeded circulars and discards everything you have entered in this demo.',
        okText: 'Reset', danger: true
      }).then(function (ok) {
        if (!ok) return;
        store.reset();
        ui.toast('Demo data restored');
        ERec.router.go('#/');
        renderAll();
      });
    });

    document.getElementById('btn-sidebar-toggle').addEventListener('click', function () {
      document.body.classList.toggle('sidebar-open');
    });
    document.getElementById('sidebar-backdrop').addEventListener('click', function () {
      document.body.classList.remove('sidebar-open');
    });
    global.addEventListener('hashchange', function () {
      document.body.classList.remove('sidebar-open');
    });

    ERec.router.start();
    renderNav();
    renderTopbar();
    storageNote();
  }

  ERec.app = { syncNav: syncNav, renderAll: renderAll, renderNav: renderNav, renderTopbar: renderTopbar };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})(window);
