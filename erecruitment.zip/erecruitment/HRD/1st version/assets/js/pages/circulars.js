/* Circular list + create. */
(function (global) {
  'use strict';

  var ERec = global.ERec;
  var store = ERec.store, ui = ERec.ui, fmt = ERec.fmt, pipe = ERec.pipeline;

  function newCircularForm() {
    var y = new Date().getFullYear();
    ui.modal({
      title: 'New circular',
      size: 'lg',
      body:
        '<div class="row g-3">' +
          '<div class="col-md-8"><label class="form-label">Circular title</label>' +
            '<input class="form-control" id="f-title" placeholder="Recruitment of Officer (IT) - ' + y + '"></div>' +
          '<div class="col-md-4"><label class="form-label">Circular no.</label>' +
            '<input class="form-control mono" id="f-code" placeholder="HRD/REC/' + y + '/04"></div>' +
          '<div class="col-md-5"><label class="form-label">Post</label>' +
            '<input class="form-control" id="f-post" placeholder="Officer (IT)"></div>' +
          '<div class="col-md-4"><label class="form-label">Department</label>' +
            '<input class="form-control" id="f-dept" placeholder="Information Technology"></div>' +
          '<div class="col-md-3"><label class="form-label">Vacancies</label>' +
            '<input type="number" min="1" class="form-control" id="f-vac" value="5"></div>' +
          '<div class="col-md-6"><label class="form-label">Application opens</label>' +
            '<input type="date" class="form-control" id="f-start" value="' + fmt.isoDate() + '"></div>' +
          '<div class="col-md-6"><label class="form-label">Application closes</label>' +
            '<input type="date" class="form-control" id="f-end" value="' + fmt.addDays(fmt.isoDate(), 30) + '"></div>' +
          '<div class="col-md-7"><label class="form-label">Examination stages</label>' +
            '<select class="form-select" id="f-chain">' +
              '<option value="MCQ,WRITTEN,VIVA">MCQ → Written → Viva-Voce</option>' +
              '<option value="MCQ,VIVA">MCQ → Viva-Voce</option>' +
              '<option value="WRITTEN,VIVA">Written → Viva-Voce</option>' +
              '<option value="VIVA">Viva-Voce only</option>' +
            '</select>' +
            '<div class="form-text">Stages can be changed later from the circular workspace.</div></div>' +
          '<div class="col-md-5"><label class="form-label">Demo applicants to generate</label>' +
            '<input type="number" min="0" max="300" class="form-control" id="f-applicants" value="40">' +
            '<div class="form-text">Sample applications so you can walk the circular straight away.</div></div>' +
        '</div>',
      footer: '<button class="btn btn-sm btn-light" data-bs-dismiss="modal">Cancel</button>' +
        '<button class="btn btn-sm btn-primary" data-act="save">Create circular</button>',
      onShow: function (api) {
        api.find('[data-act="save"]').addEventListener('click', function () {
          var title = api.find('#f-title').value.trim();
          var post = api.find('#f-post').value.trim();
          if (!title || !post) { ui.toast('Title and post are required', 'warning'); return; }
          var id = fmt.uid('C');
          store.insert('circulars', {
            id: id,
            code: api.find('#f-code').value.trim() || id,
            title: title, post: post,
            department: api.find('#f-dept').value.trim() || '—',
            vacancies: parseInt(api.find('#f-vac').value, 10) || 1,
            applyStart: api.find('#f-start').value,
            applyEnd: api.find('#f-end').value,
            status: 'ACTIVE', steps: {}
          });
          api.find('#f-chain').value.split(',').forEach(function (type, i) {
            store.insert('stages', {
              id: id + '-S' + (i + 1), circularId: id, type: type, seq: i + 1,
              name: pipe.typeLabel(type) + ' Examination',
              requireApplicantApproval: true, requireVenueApproval: false,
              applicantApprovers: [], venueApprovers: [],
              instructions: '', examDate: null,
              fullMarks: type === 'VIVA' ? 50 : 100, passMarks: type === 'VIVA' ? 25 : 50,
              status: 'NOT_STARTED', steps: {}
            });
          });
          /* Generate sample applications, otherwise the new circular has an
             empty candidate list and cannot be walked through at all. */
          var n = parseInt(api.find('#f-applicants').value, 10);
          if (isNaN(n) || n < 0) n = 0;
          if (n > 0) {
            ERec.seed.makeApplicants({
              circularId: id, count: n,
              prefix: (api.find('#f-code').value.trim() || id).replace(/\W+/g, '').slice(-6).toUpperCase() || 'APP',
              appliedAt: api.find('#f-start').value
            }).forEach(function (a) { store.insert('applicants', a); });
          }

          store.audit('CREATE_CIRCULAR', 'circular', id,
            'Circular ' + post + ' created with ' + fmt.plural(n, 'applicant'));
          api.close();
          ui.toast('Circular created' + (n ? ' with ' + fmt.plural(n, 'applicant') : ''));
          ERec.app.renderNav();
          ERec.router.go('#/circular/' + id);
        });
      }
    });
  }

  function render(view) {
    ERec.router.setCrumbs([{ label: 'Circulars' }]);
    var list = store.all('circulars');

    var rows = list.map(function (c) {
      var p = pipe.circularProgress(c.id);
      var n = store.applicantsOf(c.id).length;
      var active = pipe.activeStage(c.id);
      var cur = active ? pipe.currentStep(active) : null;
      return '<tr class="clickable" data-cid="' + c.id + '">' +
        '<td><div class="name-cell"><div><div class="n">' + fmt.esc(c.post) + '</div>' +
          '<div class="m mono">' + fmt.esc(c.code) + '</div></div></div></td>' +
        '<td>' + fmt.esc(c.department) + '</td>' +
        '<td class="num">' + c.vacancies + '</td>' +
        '<td class="num">' + n + '</td>' +
        '<td class="nowrap">' + fmt.esc(pipe.chainLabel(c.id)) + '</td>' +
        '<td style="min-width:150px">' + ui.progressBar(p.pct) +
          '<div class="fs-12 muted mt-1">' + (cur ? fmt.esc(cur.label) : 'Complete') + '</div></td>' +
        '<td>' + ui.statusPill(c.status) + '</td>' +
        '<td class="nowrap text-end"><a class="btn btn-sm btn-light" href="#/circular/' + c.id + '">Open <i class="bi bi-chevron-right"></i></a></td>' +
        '</tr>';
    }).join('');

    view.innerHTML = ui.pageHead({
      title: 'Circulars',
      sub: 'Every recruitment circular and where it stands in the pipeline.',
      actions: '<button class="btn btn-sm btn-primary btn-icon" id="btn-new"><i class="bi bi-plus-lg"></i> New circular</button>'
    }) + ui.card({
      tight: true,
      body: list.length ? '<div class="table-scroll"><table class="table-x"><thead><tr>' +
        '<th>Post / circular no.</th><th>Department</th><th class="num">Vacancy</th><th class="num">Applied</th>' +
        '<th>Stages</th><th>Progress</th><th>Status</th><th></th></tr></thead><tbody>' + rows + '</tbody></table></div>'
        : ui.empty('No circulars yet', 'Create one to start the recruitment pipeline.', 'bi-megaphone')
    });

    view.querySelector('#btn-new').addEventListener('click', newCircularForm);
    ui.on(view, 'tr[data-cid]', 'click', function (e, tr) {
      if (e.target.closest('a')) return;
      ERec.router.go('#/circular/' + tr.dataset.cid);
    });
  }

  ERec.pages.circulars = { render: render, newCircularForm: newCircularForm };
})(window);
