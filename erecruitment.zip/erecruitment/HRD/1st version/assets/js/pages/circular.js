/* Circular workspace: configure the exam stage chain, set approver chains,
   and see the whole pipeline at a glance. */
(function (global) {
  'use strict';

  var ERec = global.ERec;
  var store = ERec.store, ui = ERec.ui, fmt = ERec.fmt, pipe = ERec.pipeline;

  var TYPES = ['MCQ', 'WRITTEN', 'VIVA'];

  /* Ordered approver picker - the order of selection is the approval order.
     Opened from the approval step, which is where approvers are set up. */
  function editApprovers(stg, kind) {
    var field = kind === 'APPLICANT' ? 'applicantApprovers' : 'venueApprovers';
    var chosen = (stg[field] || []).slice();
    var approvers = store.where('users', function (u) { return u.role === 'APPROVER'; });

    function listHtml() {
      var picked = chosen.map(function (id, i) {
        var u = store.find('users', id);
        return '<div class="d-flex align-items-center gap-2 border rounded p-2 mb-2">' +
          '<span class="pill blue">L' + (i + 1) + '</span>' +
          '<div class="flex-grow-1"><div class="fw-semibold fs-13">' + fmt.esc(u.name) + '</div>' +
          '<div class="fs-12 muted">' + fmt.esc(u.designation) + '</div></div>' +
          '<button class="btn btn-sm btn-light" data-up="' + id + '"' + (i === 0 ? ' disabled' : '') + '><i class="bi bi-arrow-up"></i></button>' +
          '<button class="btn btn-sm btn-light" data-down="' + id + '"' + (i === chosen.length - 1 ? ' disabled' : '') + '><i class="bi bi-arrow-down"></i></button>' +
          '<button class="btn btn-sm btn-outline-danger" data-rm="' + id + '"><i class="bi bi-x-lg"></i></button>' +
          '</div>';
      }).join('');

      var avail = approvers.filter(function (u) { return chosen.indexOf(u.id) < 0; });
      return '<div class="section-title">Approval sequence</div>' +
        (picked || '<div class="fs-13 muted mb-2">No approver selected — this approval step can still be skipped.</div>') +
        '<div class="section-title">Add approver</div>' +
        (avail.length ? avail.map(function (u) {
          return '<button class="btn btn-sm btn-light d-flex align-items-center gap-2 w-100 mb-2 text-start" data-add="' + u.id + '">' +
            ui.avatar(u.name, 'sm') +
            '<span><span class="d-block fw-semibold fs-13">' + fmt.esc(u.name) + '</span>' +
            '<span class="d-block fs-12 muted">' + fmt.esc(u.designation) + '</span></span>' +
            '<i class="bi bi-plus-lg ms-auto"></i></button>';
        }).join('') : '<div class="fs-12 muted">All approvers added.</div>');
    }

    var m = ui.modal({
      title: 'Approvers · ' + pipe.typeLabel(stg.type) + ' · ' + (kind === 'APPLICANT' ? 'Applicant list' : 'Venue'),
      body: '<div id="ap-body">' + listHtml() + '</div>',
      footer: '<button class="btn btn-sm btn-light" data-bs-dismiss="modal">Cancel</button>' +
        '<button class="btn btn-sm btn-primary" data-act="save">Save sequence</button>',
      onShow: function (api) {
        function rebind() {
          var body = api.find('#ap-body');
          body.innerHTML = listHtml();
          body.querySelectorAll('[data-add]').forEach(function (b) {
            b.addEventListener('click', function () { chosen.push(b.dataset.add); rebind(); });
          });
          body.querySelectorAll('[data-rm]').forEach(function (b) {
            b.addEventListener('click', function () {
              chosen = chosen.filter(function (x) { return x !== b.dataset.rm; }); rebind();
            });
          });
          body.querySelectorAll('[data-up]').forEach(function (b) {
            b.addEventListener('click', function () {
              var i = chosen.indexOf(b.dataset.up);
              if (i > 0) { chosen.splice(i - 1, 0, chosen.splice(i, 1)[0]); rebind(); }
            });
          });
          body.querySelectorAll('[data-down]').forEach(function (b) {
            b.addEventListener('click', function () {
              var i = chosen.indexOf(b.dataset.down);
              if (i < chosen.length - 1) { chosen.splice(i + 1, 0, chosen.splice(i, 1)[0]); rebind(); }
            });
          });
        }
        rebind();
        api.find('[data-act="save"]').addEventListener('click', function () {
          var patch = {};
          patch[field] = chosen;
          store.update('stages', stg.id, patch);
          store.audit('SET_APPROVERS', 'stage', stg.id, kind + ' approvers updated for ' + pipe.typeLabel(stg.type));
          api.close();
          ui.toast('Approval sequence saved');
          ERec.router.refresh();
        });
      }
    });
    return m;
  }

  function stageHasProgress(stg) {
    return Object.keys(stg.steps || {}).length > 0;
  }

  function resequence(circularId) {
    store.stagesOf(circularId).forEach(function (s, i) { s.seq = i + 1; });
    store.save();
  }

  function addStage(circularId) {
    var stages = store.stagesOf(circularId);
    ui.modal({
      title: 'Add examination stage',
      body: '<label class="form-label">Stage type</label>' +
        '<select class="form-select" id="f-type">' +
        TYPES.map(function (t) { return '<option value="' + t + '">' + pipe.typeLabel(t) + '</option>'; }).join('') +
        '</select>' +
        '<div class="form-text mt-2">The new stage is appended at the end of the chain. ' +
        'Roll numbers are generated at the first stage, and scrutiny appears automatically on a Viva-Voce stage.</div>',
      footer: '<button class="btn btn-sm btn-light" data-bs-dismiss="modal">Cancel</button>' +
        '<button class="btn btn-sm btn-primary" data-act="add">Add stage</button>',
      onShow: function (api) {
        api.find('[data-act="add"]').addEventListener('click', function () {
          var type = api.find('#f-type').value;
          store.insert('stages', {
            id: fmt.uid('stg'), circularId: circularId, type: type, seq: stages.length + 1,
            name: pipe.typeLabel(type) + ' Examination',
            requireApplicantApproval: false, requireVenueApproval: false,
            applicantApprovers: [], venueApprovers: [],
            instructions: '', examDate: null,
            fullMarks: type === 'VIVA' ? 50 : 100, passMarks: type === 'VIVA' ? 25 : 50,
            status: 'NOT_STARTED', steps: {}
          });
          store.audit('ADD_STAGE', 'circular', circularId, pipe.typeLabel(type) + ' stage added');
          api.close();
          ui.toast('Stage added');
          ERec.router.refresh();
        });
      }
    });
  }

  /* One compact line per approval point. The switches and the approver
     sequence itself are edited on the approval step, where the user is
     actually doing that job - this screen only says what is set up. */
  function approvalSummary(stg, kind) {
    var required = kind === 'APPLICANT' ? stg.requireApplicantApproval : stg.requireVenueApproval;
    var ids = (kind === 'APPLICANT' ? stg.applicantApprovers : stg.venueApprovers) || [];
    var label = kind === 'APPLICANT' ? 'Candidate list' : 'Venue';
    var route = '#/circular/' + stg.circularId + '/stage/' + stg.id + '/' +
      (kind === 'APPLICANT' ? 'approval-applicant' : 'approval-venue');
    return '<div class="appr-line">' +
      '<span class="appr-what">' + label + '</span>' +
      (required ? ui.pill('Required', 'blue') : ui.pill('Optional', 'outline')) +
      '<span class="appr-who">' + (ids.length
        ? ids.map(function (id, i) {
          var u = store.find('users', id);
          return (i ? ' → ' : '') + fmt.esc(u ? u.name : id);
        }).join('')
        : '<span class="muted">no approver set</span>') + '</span>' +
      '<a class="appr-set" href="' + route + '">Set up</a>' +
      '</div>';
  }

  function stageRow(stg, i, total) {
    var p = pipe.progress(stg);
    var locked = stageHasProgress(stg);
    return '<tr data-sid="' + stg.id + '">' +
      '<td class="nowrap"><span class="pill blue">Stage ' + stg.seq + '</span></td>' +
      '<td>' +
        '<select class="form-select form-select-sm" data-type="' + stg.id + '" style="width:132px"' +
          (locked ? ' disabled title="This stage has already been started"' : '') + '>' +
        TYPES.map(function (t) {
          return '<option value="' + t + '"' + (t === stg.type ? ' selected' : '') + '>' + pipe.typeLabel(t) + '</option>';
        }).join('') + '</select>' +
        (stg.seq === 1 ? '<div class="fs-12 muted mt-1"><i class="bi bi-123"></i> roll numbers are given here</div>' : '') +
        (stg.type === 'VIVA' ? '<div class="fs-12 muted mt-1"><i class="bi bi-folder-check"></i> includes document scrutiny</div>' : '') +
      '</td>' +
      '<td>' + approvalSummary(stg, 'APPLICANT') + approvalSummary(stg, 'VENUE') + '</td>' +
      '<td style="min-width:130px">' + ui.progressBar(fmt.pct(p.done, p.total)) +
        '<div class="fs-12 muted mt-1">' + p.done + ' of ' + p.total + ' steps' +
        (p.pending ? ' · <span class="text-warning fw-semibold">' + p.pending + ' waiting</span>' : '') + '</div></td>' +
      '<td class="text-end nowrap">' +
        '<a class="btn btn-sm btn-light" href="#/circular/' + stg.circularId + '/stage/' + stg.id + '">Open</a> ' +
        '<button class="btn btn-sm btn-light" data-move="up" data-sid="' + stg.id + '"' + (i === 0 ? ' disabled' : '') + ' title="Move earlier"><i class="bi bi-arrow-up"></i></button> ' +
        '<button class="btn btn-sm btn-light" data-move="down" data-sid="' + stg.id + '"' + (i === total - 1 ? ' disabled' : '') + ' title="Move later"><i class="bi bi-arrow-down"></i></button> ' +
        '<button class="btn btn-sm btn-outline-danger" data-del="' + stg.id + '" title="Remove stage"><i class="bi bi-trash"></i></button>' +
      '</td></tr>';
  }

  function pipelineMap(c) {
    var stages = store.stagesOf(c.id);
    return stages.map(function (s) {
      var steps = pipe.steps(s);
      var p = pipe.progress(s);
      return '<div class="mb-3">' +
        '<div class="d-flex align-items-center gap-2 mb-2">' +
          '<span class="pill ' + (p.done === p.total ? 'green' : 'blue') + '">Stage ' + s.seq + '</span>' +
          '<span class="fw-semibold">' + fmt.esc(pipe.stageName(s)) + '</span>' +
          '<span class="fs-12 muted">' + p.done + '/' + p.total + ' required steps</span>' +
          '<div class="spacer flex-grow-1"></div>' +
          '<a class="btn btn-sm btn-light" href="#/circular/' + c.id + '/stage/' + s.id + '">Open stage <i class="bi bi-chevron-right"></i></a>' +
        '</div>' +
        '<div class="d-flex flex-wrap gap-1">' + steps.map(function (st) {
          var tone = st.done ? (st.skipped ? 'outline' : 'green') : (st.enabled ? 'blue' : 'grey');
          var icon = st.done ? (st.skipped ? 'bi-dash-lg' : 'bi-check-lg') : (st.enabled ? 'bi-play-fill' : 'bi-lock-fill');
          return '<a href="' + st.route + '" class="pill ' + tone + '" title="' + fmt.esc(st.blockedReason || st.label) + '">' +
            '<i class="bi ' + icon + '"></i>' + fmt.esc(st.label) + (st.optional ? ' <span class="opt-tag">opt</span>' : '') + '</a>';
        }).join('') + '</div></div>';
    }).join('<hr class="hr-soft">');
  }

  function render(view, params) {
    var c = store.circular(params.cid);
    if (!c) { ERec.router.go('#/circulars'); return; }
    ERec.router.setCrumbs([{ label: 'Circulars', href: '#/circulars' }, { label: c.post }]);

    var stages = store.stagesOf(c.id);
    var applicants = store.applicantsOf(c.id);
    var active = pipe.activeStage(c.id);
    var cur = active ? pipe.currentStep(active) : null;

    var html = ui.pageHead({
      title: fmt.esc(c.post),
      sub: fmt.esc(c.title) + ' · <span class="mono">' + fmt.esc(c.code) + '</span>',
      actions: (cur ? '<a class="btn btn-sm btn-primary btn-icon" href="' + cur.route + '"><i class="bi bi-play-fill"></i> Continue: ' + fmt.esc(cur.label) + '</a>' : '')
    });

    html += '<div class="stat-grid">' +
      '<div class="stat"><div class="k">Applicants</div><div class="v">' + applicants.length + '</div></div>' +
      '<div class="stat"><div class="k">Vacancies</div><div class="v">' + c.vacancies + '</div></div>' +
      '<div class="stat"><div class="k">Stages</div><div class="v">' + stages.length + '<small> · ' + fmt.esc(pipe.chainLabel(c.id)) + '</small></div></div>' +
      '<div class="stat"><div class="k">Application window</div><div class="v" style="font-size:14px">' +
        fmt.date(c.applyStart) + ' – ' + fmt.date(c.applyEnd) + '</div></div>' +
      '</div>';

    html += ui.card({
      title: 'Examination stages',
      hint: 'Which examinations this circular runs, and in what order. Roll numbers are given at stage 1, and any Viva-Voce stage automatically includes document scrutiny.',
      actions: '<button class="btn btn-sm btn-primary btn-icon" id="btn-add-stage"><i class="bi bi-plus-lg"></i> Add stage</button>',
      tight: true,
      body: stages.length ? '<div class="table-scroll"><table class="table-x"><thead><tr>' +
        '<th>Order</th><th>Examination</th><th style="min-width:300px">Approvals</th>' +
        '<th>Progress</th><th></th>' +
        '</tr></thead><tbody>' +
        stages.map(function (s, i) { return stageRow(s, i, stages.length); }).join('') +
        '</tbody></table></div>'
        : ui.empty('No stages configured', 'Add at least one examination stage to start.', 'bi-diagram-3')
    });

    html += ui.card({
      title: 'Pipeline map',
      hint: 'Every step of every stage. Green is done, dashed is skipped, grey is locked until the step before it finishes.',
      body: stages.length ? pipelineMap(c) : ui.empty('Nothing to show yet')
    });

    view.innerHTML = html;

    view.querySelector('#btn-add-stage').addEventListener('click', function () { addStage(c.id); });

    ui.on(view, '[data-type]', 'change', function (e, sel) {
      var stg = store.stage(sel.dataset.type);
      store.update('stages', stg.id, {
        type: sel.value, name: pipe.typeLabel(sel.value) + ' Examination',
        fullMarks: sel.value === 'VIVA' ? 50 : 100, passMarks: sel.value === 'VIVA' ? 25 : 50
      });
      ui.toast('Stage type changed to ' + pipe.typeLabel(sel.value));
      ERec.router.refresh();
    });

    ui.on(view, '[data-move]', 'click', function (e, b) {
      var list = store.stagesOf(c.id);
      var i = list.findIndex(function (s) { return s.id === b.dataset.sid; });
      var j = b.dataset.move === 'up' ? i - 1 : i + 1;
      if (j < 0 || j >= list.length) return;
      var a = list[i].seq; list[i].seq = list[j].seq; list[j].seq = a;
      store.save();
      ERec.router.refresh();
    });

    ui.on(view, '[data-del]', 'click', function (e, b) {
      var stg = store.stage(b.dataset.del);
      ui.confirm({
        title: 'Remove stage',
        body: 'Remove the <strong>' + fmt.esc(pipe.typeLabel(stg.type)) + '</strong> stage?' +
          (stageHasProgress(stg) ? ' <span class="text-danger">This stage already has completed steps; its roster, venues, marks and approvals will be discarded.</span>' : ''),
        okText: 'Remove', danger: true
      }).then(function (ok) {
        if (!ok) return;
        store.where('stageApplicants', function (r) { return r.stageId === stg.id; })
          .forEach(function (r) { store.remove('stageApplicants', r.id); });
        store.where('venues', function (v) { return v.stageId === stg.id; })
          .forEach(function (v) { store.remove('venues', v.id); });
        store.where('approvals', function (a) { return a.stageId === stg.id; })
          .forEach(function (a) { store.remove('approvals', a.id); });
        store.remove('stages', stg.id);
        resequence(c.id);
        store.audit('REMOVE_STAGE', 'circular', c.id, pipe.typeLabel(stg.type) + ' stage removed');
        ui.toast('Stage removed');
        ERec.router.refresh();
      });
    });
  }

  ERec.pages.circular = { render: render, editApprovers: editApprovers };
})(window);
