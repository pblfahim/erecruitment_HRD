/* Dashboard - one compact card per circular.
   No cross-circular totals on purpose: "105 applicants" across three
   unrelated recruitments tells an HR officer nothing they can act on.
   Every figure on a card belongs to that circular and its stages. */
(function (global) {
  'use strict';

  var ERec = global.ERec;
  var store = ERec.store, ui = ERec.ui, fmt = ERec.fmt, pipe = ERec.pipeline;

  function circularCard(c) {
    var stages = store.stagesOf(c.id);
    var applicants = store.applicantsOf(c.id);
    var prog = pipe.circularProgress(c.id);
    var active = pipe.activeStage(c.id);
    var cur = active ? pipe.currentStep(active) : null;

    var chips = stages.map(function (s) {
      var p = pipe.progress(s);
      var roster = store.rosterOf(s.id);
      var complete = p.done === p.total && !p.pending;
      var cls = complete ? 'done' : (active && s.id === active.id ? 'cur' : '');
      return '<span class="stage-chip ' + cls + '" title="' +
        fmt.esc(pipe.typeLabel(s.type) + ' · ' +
          (roster.length ? fmt.plural(roster.length, 'candidate') : 'no candidates yet')) + '">' +
        (complete ? '<i class="bi bi-check-circle-fill"></i>' : '') +
        fmt.esc(pipe.typeLabel(s.type)) +
        (roster.length ? ' <span class="cnt">' + roster.length + '</span>' : '') +
        (p.pending ? ' <span class="wait">' + p.pending + '</span>' : '') +
        '</span>';
    }).join('<span class="arrow"><i class="bi bi-chevron-right"></i></span>');

    return '<div class="col-xl-4 col-md-6">' + ui.card({
      cls: 'circ-card',
      body:
        '<div class="d-flex align-items-start gap-2 mb-2">' +
          '<div class="flex-grow-1 min-w-0">' +
            '<div class="fw-semibold text-truncate" style="font-size:15px">' + fmt.esc(c.post) + '</div>' +
            '<div class="fs-12 muted mono">' + fmt.esc(c.code) + '</div>' +
          '</div>' + ui.statusPill(c.status) +
        '</div>' +
        '<div class="chain mb-3">' + chips + '</div>' +
        '<div class="d-flex gap-3 fs-12 muted mb-2 flex-wrap">' +
          '<span><i class="bi bi-people"></i> ' + applicants.length + ' applied</span>' +
          '<span><i class="bi bi-bullseye"></i> ' + c.vacancies + ' vacancies</span>' +
          '<span><i class="bi bi-calendar-event"></i> closed ' + fmt.date(c.applyEnd) + '</span>' +
        '</div>' +
        ui.progressBar(prog.pct) +
        '<div class="d-flex justify-content-between fs-12 muted mt-1">' +
          '<span>' + prog.done + ' / ' + prog.total + ' steps</span><span>' + prog.pct + '%</span>' +
        '</div>' +
        (cur
          ? '<div class="alert-x ' + (cur.pending ? 'warn' : 'info') + ' mt-3 mb-0">' +
            '<i class="bi ' + (cur.pending ? 'bi-people' : 'bi-signpost-2') + '"></i><div>' +
            '<div class="fw-semibold">Next: ' + fmt.esc(cur.label) + '</div>' +
            '<div class="fs-12">' + fmt.esc(pipe.stageName(active)) +
            (cur.pending ? ' · ' + fmt.plural(cur.pending, 'candidate') + ' waiting' : '') +
            '</div></div></div>'
          : ''),
      foot:
        (cur
          ? '<a class="btn btn-sm btn-primary btn-icon" href="' + cur.route + '">' +
            '<i class="bi bi-play-fill"></i> Continue</a>'
          : '<span class="pill green"><i class="bi bi-check-lg"></i>Complete</span>') +
        '<a class="btn btn-sm btn-light" href="#/circular/' + c.id + '">Configure stages</a>'
    }) + '</div>';
  }

  function render(view) {
    ERec.router.setCrumbs([{ label: 'Dashboard' }]);

    var circulars = store.all('circulars');
    var me = store.actingUser();
    var minePending = store.pendingApprovalsFor(me.id).length;

    var html = ui.pageHead({
      title: 'Recruitment Dashboard',
      sub: 'Signed in as ' + fmt.esc(me.name) + ' · ' + fmt.esc(me.designation),
      actions: '<button class="btn btn-sm btn-primary btn-icon" id="btn-new"><i class="bi bi-plus-lg"></i> New circular</button>' +
        '<a class="btn btn-sm btn-light btn-icon ms-2" href="#/outbox"><i class="bi bi-envelope-paper"></i> Outbox</a>'
    });

    if (minePending) {
      html += ui.alert('warn',
        '<strong>' + fmt.plural(minePending, 'request') + ' awaiting your approval.</strong> ' +
        '<a href="#/approvals" class="fw-semibold">Open approval inbox</a>');
    }

    html += circulars.length
      ? '<div class="row g-3 mb-2">' + circulars.map(circularCard).join('') + '</div>'
      : ui.card({ body: ui.empty('No circular yet', 'Create one to start a recruitment.', 'bi-megaphone') });

    var log = store.all('auditLog').slice(0, 8);
    html += ui.card({
      title: 'Recent activity',
      body: log.length ? '<div class="timeline">' + log.map(function (l) {
        return '<div class="tl-item ok"><span class="tl-dot"><i class="bi bi-dot"></i></span>' +
          '<div class="tl-title">' + fmt.esc(l.note || l.action) + '</div>' +
          '<div class="tl-meta">' + fmt.esc(l.userName) + ' · ' + fmt.ago(l.at) + '</div></div>';
      }).join('') + '</div>' : ui.empty('No activity yet', 'Actions you take in the demo show up here.', 'bi-clock-history')
    });

    view.innerHTML = html;
    view.querySelector('#btn-new').addEventListener('click', function () {
      ERec.pages.circulars.newCircularForm();
    });
  }

  ERec.pages.dashboard = { render: render };
})(window);
