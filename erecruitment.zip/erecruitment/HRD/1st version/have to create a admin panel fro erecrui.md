have to create a admin panel fro erecruitment system, the business logic in defined below:

processes:
1. Search applicant - show pdf, generate exceel, pdf
2. Applicant appraoval in every exam stage, not mandatory but options need to show, he can also set up the approver too for each circualr and exam stage wise  
3. exam stage can be-> MCQ, Written, viva or written, viva or mcq , viva or direct viva , user can set up the stage
4. roll number generation-> before 1st exam(mcq or written or viva which one is first) initiate set up roll number
4. Venue -> user can set up the venue where circular wise includes where, when, from and to roll number range, for which exam (mcq or written or viva) 
5. venue approval in every exam stage, not mandatory but options need to show, he can also set up the approver too for each circualr and exam stage wise 
6. Exam instruction ->  Before initiate exam user must add the relavent exam instruction that will show up in the admit card of the applicants in written or mcq or viva stage
7. Initiate Exam-> while initiate exam the user must show up the mail and sms body what will provided to the applicants, he can update the text too
8. mark upload-> after each exam the user upload the mark of the applicants, can search by cut off marks, if satisfied he accept and can forward them to next stage like if mark upload for mcq then he can set for written or viva chooseable, if viva then finally selected to get offer later, user can further generate the selection if panel wise appliant call needed or update the list(take less or more).
instead of cut off mark, use may need to provide the privilages to select the applicant for next stage  
9. Scrutiny -> Before viva user match the applicants profile in application with their documents(hard copy) they asked to get in on the viva day, if the user satisfied with the macthing with their docs then the user mark accepted for viva else rejected or the user can keep some remarks to give some time to the aplicant to get in the documents later before joining and provide contional accpetance for viva, the user can further show their documents later and the can mark his his status as accept upon satisfaction or reject.
First the admin(hr personeel) find a page where he can search by current active circualr,
in search result 
10. after successfull result the user generate final result and then again the finally selected applicant get mail and sms ( the user must show up the mail and sms body what will provided to the applicants, he can update the text too)
11. the user can generate offer later for the selected candidte
12. on the day of joining when the applcants come to join the user initiate joining 

so in specifically the way will be

# For MCQ->Written->Viva (1st MCQ)
# MCQ 
search applicant by circular ->
send for approval (if required) with set up of approver -> generate roll number -> set up venue->send for approval (if required) with set up of approver->Set up instrauction->initiale Exam -> mark upload(search by cut off or select manually) -> send for next stage (Written or viva)
# written
search applicant by circular ->
->send for approval (if required) with set up of approver -> set up venue->send for approval (if required) with set up of approver->Set up instrauction->initiale Exam -> mark upload(search by cut off or select manually) -> send for next stage (viva)
# Viva
search applicant by circular ->
->send for approval (if required) with set up of approver -> set up venue->send for approval (if required) with set up of approver->Set up instrauction->initiale Exam ->Scrutiny -> mark upload(search by cut off or select manually)->generate final result->generate offer later->initiate joining 

# For MCQ/Written->Viva (1st MCQ or Written)
search applicant by circular ->
send for approval (if required) with set up of approver -> generate roll number -> set up venue->send for approval (if required) with set up of approver->Set up instrauction->initiale Exam -> mark upload(search by cut off or select manually) -> send for next stage ( viva)
# Viva
search applicant by circular ->
->send for approval (if required) with set up of approver -> set up venue->send for approval (if required) with set up of approver->Set up instrauction->initiale Exam ->Scrutiny -> mark upload(search by cut off or select manually)->generate final result->generate offer later->initiate joining 

# Just Viva
search applicant by circular ->
->send for approval (if required) with set up of approver -> set up venue->send for approval (if required) with set up of approver->Set up instrauction->initiale Exam ->Scrutiny -> mark upload(search by cut off or select manually)->generate final result->generate offer later->initiate joining 


Now you should analyze and create view of this whole module. you can create html, css, bootstrap as needed. We need to make sure to make the module as easy to navigate. You can think of steppers if you think its feasinble. User should go through the phases described above. For demo, you can also add/save data on browser cache/cookies as needed or in memory. Now share me the plan