# e-Recruitment Admin Panel — Demo

Open **`index.html`** (double-click it). No server, no build, no install.
Everything is saved in your browser, so you can close the tab and come back later.

> The first load needs internet (Bootstrap comes from a CDN). Everything else is local.

---

## How a screen is laid out

Every step screen follows the same shape, so there is nothing new to learn after the first one:

```
← Officer (Cash)   [Viva-Voce Examination]     Step 4 of 10 · 3 of 9 steps done

 ①Candidate  ─ ②Approve ─ ③Roll ─ ④Venue ─ ⑤Approve ─ ⑥Instructions ─ …
   List         List       Numbers  & Seating  Venue
   16 candidates  Approved   16 rolls  ← you are here

Venue & Seating
Say where and when the examination is held, and which roll numbers sit in which hall.

   … the work for this step …

────────────────────────────────────────────────────────────────────
← Roll Numbers                     Change plan   [ Confirm venue plan ]
```

- The **stepper** names every step and shows what it produced ("16 candidates", "2 venues",
  "Approved", "Skipped"). Click any unlocked step to jump straight to it.
- Green tick = done, blue = where you are, padlock = not open yet. An **orange badge on a
  step** means candidates are waiting on it.
- Under the stepper, the current step is spelled out with **one sentence saying what to do**.
- The **one big button at the bottom right** is always the thing to do next. If the step is
  already finished it turns into *Continue: <next step>*.
- Small grey buttons beside it are the "only if you need it" actions.

## The dashboard

One compact card per circular. Every figure on a card belongs to **that** circular — there
are no cross-circular totals, because "105 applicants" across three unrelated recruitments is
not something anyone can act on.

Each card carries the stage chain as chips with **that stage's candidate count** on them
(`MCQ ✓ 45 › Written 28 › Viva`), an orange badge when candidates are waiting at a stage, the
circular's applied / vacancy / closing figures, its progress bar, and a **Next:** line naming
the exact step to go to.

## Where things are

`Approvals` and `Outbox` are the 3rd and 4th items in the dark sidebar on the left. You will
not find them written in `index.html`, because the whole sidebar is built at runtime by
`assets/js/app.js` into the empty `<nav id="sidebar-nav">`. Their URLs are `#/approvals` and
`#/outbox`.

| Screen | Why it exists |
|---|---|
| **Approvals** | The approver's side of the workflow. When you "send for approval", somebody has to actually approve it — that happens here, after you switch **Acting as** in the top right. |
| **Mail / SMS Outbox** | Every e-mail and SMS the system actually sent, with the exact merged text each candidate received. Second tab holds the full activity log. |

---

## What is already loaded

| Circular | Post | Stage chain | Starts at |
|---|---|---|---|
| `C-2026-01` | Officer (Cash) | MCQ → Written → Viva | MCQ finished, sitting at **Written / Venue** |
| `C-2026-02` | Management Trainee Officer | Written → Viva | Written finished, sitting at **Viva / Scrutiny** |
| `C-2026-03` | Consultant (Legal) | Viva only | Nothing done — walk it from step 1 |

**Reset demo data** (bottom of the sidebar) puts all three back exactly as above.

---

## Starting from scratch — create your own circular

**New circular** (dashboard top right, or the Circulars screen) asks for the title, post,
department, vacancies, application window, the **stage chain**, and **how many demo applicants
to generate** (default 40).

That last field matters: a circular with no applications cannot be walked through at all, so
sample applications — names, parents' names, NID, mobile, e-mail, district, three academic
records, some with experience, each with a document list — are generated with it. You land on
the new circular with its stages configured and its candidate list ready to confirm.

If you set it to 0, or want a longer list later, the Candidate List step has an **Add demo
applicants** button that tops the circular up (application numbers carry on from where they
left off).

From there the walkthrough below applies to your own circular exactly as it does to the
seeded ones.

## Full walkthrough — first step to last

Use **`C-2026-03 · Consultant (Legal)`**. It is a Viva-only circular, so it is the shortest
path that still touches *every* step. From the Dashboard, click **Continue** on its card.

### 1. Candidate List
- 22 applicants are listed, all pre-ticked.
- Try the filters. The count at the top stays correct as you filter, and **Clear all
  selections** clears everyone, not just the rows you can see.
- Click any row to read the full application. **Print profile (PDF)** works.
- Big button: **Confirm 22 candidates**.

### 2. Approve Candidate List — *optional, worth doing properly once*
- **Set up** the approver sequence → add **Md. Rafiqul Islam**, then **Sabina Haque**. They
  become L1 and L2 and must approve in that order.
- Big button: **Send for approval**.
- **Top right → Acting as → Md. Rafiqul Islam.** A red badge appears on **Approvals**.
- Open **Approvals** → **Approve** with a remark. It moves on to Sabina Haque.
- Switch to **Sabina Haque**, approve again. The step turns green.
- Switch back to **Shahnaz Parvin** (HR Admin).

> Or just press **Skip — not needed**. Optional steps never hold up the ones behind them.

### 3. Roll Numbers
- This step appears here even though it is a viva: roll numbers attach to whichever stage is
  **first**. On C-2026-01 you will see it only on MCQ.
- Set prefix, digits and ordering — the preview updates live. Then **Generate roll numbers**.

### 4. Venue & Seating
- **Auto-split** creates 2 centres, or **Add venue** to enter one by hand (name, address,
  date, times, roll-from / roll-to, capacity).
- Try a roll range that misses somebody, or a capacity below the number allocated — you get
  warned.
- The list icon on a row shows the seat plan and prints an **attendance sheet**.
- Big button: **Confirm venue plan**.

### 5. Approve Venue — *optional*
- Press **Skip — not needed**.

### 6. Exam Instructions
- **Load standard Viva-Voce set**, edit a line, and watch the **admit card preview** change
  as you type. Then **Save instructions**.

### 7. Send Exam Notice
- The e-mail body and the SMS body are both shown and **fully editable**.
- Click a chip like `{{venue}}` to drop it in at your cursor.
- The right side previews the merged text against a real candidate; change the dropdown to
  check another one. Watch the SMS character / parts counter.
- Big button: **Send to 22 candidates**.
- Open **Outbox** — every mail and SMS is there. Come back for **Print all admit cards**.

### 8. Document Scrutiny — *viva stages only*
- Click a candidate to open the document checklist. Do all three outcomes on three people:
  - tick everything → **Accept**
  - leave one unticked, add a remark and a date → **Conditional**
  - add a remark → **Reject**
- Filter buttons group them. A conditional case can be reopened and settled at any time.
- Big button: **Finish scrutiny**. Rejected candidates drop out of the next step.

### 9. Marks & Selection
- **Full marks** and **pass marks** sit at the top right of the mark sheet — set them here,
  where you are actually entering marks.
- Type marks into the grid, or **Import marks** and paste `roll,marks` lines
  (`26030001,42`). Use `absent` in place of a number.
- **By cut-off**: enter a cut-off, see the live count, **Apply cut-off**.
- **Manual selection**: switch mode and tick people by hand.
- **Privilege**: the ★ on a row selects someone regardless of the cut-off; you must state the
  ground. It survives a later cut-off run.
- Big button: **Accept N selected candidates**.

### 10. Final Result
- The merit list adds up marks across every stage. Un-tick anyone who should not appear.
- Edit the result mail/SMS, then **Publish result for N candidates**.

### 11. Offer Letter
- **Issue N offer letters** → reference prefix, joining date, salary, and the offer wording.
- **Letter** on a row prints a proper offer letter. Then **Finish the offer stage**.

### 12. Joining
- **Initiate joining** on a candidate. Anyone **conditionally accepted at scrutiny** has their
  outstanding documents listed right there for a final tick — that is the loop closing.
- Assign an Employee ID, confirm, then **Close this recruitment**.

---

## Calling more candidates into a stage

*"I called 50 for the viva, they joined. Now I want 10 more from the written pool."*

Open the stage (say **Viva**) → step 1 **Candidate List** → **Call more candidates**.

- You get everyone who sat the **previous** examination but was never called for this one,
  ranked highest mark first, with their marks shown.
- **Take the top N** ticks the best N in one click, or tick people individually.
- Optionally put them on an **interview panel** — an existing one, or create a new panel with
  its own date for the supplementary call.
- Record the reason ("4 selected candidates did not join").

What happens then is the important part — **nothing already done is undone**:

- The newcomers keep the roll number they already had.
- Every earlier step stays green. Candidates already scrutinised keep their scrutiny result,
  and candidates already marked keep their marks.
- The steps that still have work for the newcomers show an **orange count** on the progress
  track: Venue, Send Exam Notice, Scrutiny, Marks.
- **Continue** now takes you to the first step where people are waiting, not to the end.
- On **Send Exam Notice** the big button becomes **"Send to the 3 new candidates"** — the
  candidates who already have their admit card are not contacted again. *Send again to
  everyone* is still there if you want it.
- A candidate whose roll already falls inside an existing hall's roll range is seated
  automatically and is **not** counted as waiting — you are only told about the ones that
  genuinely need the venue plan extended.
- The previous stage's record is updated too, so its result sheet shows those candidates as
  taken forward.

Newly called candidates carry a **Call 2** tag in the list so you can always tell which round
somebody came in on.

---

## Two-minute checks on the other flow variants

**`C-2026-01` (MCQ → Written → Viva)** — proves the steps change with the chain:

- **MCQ**: all green, and it **has** a Roll Numbers step.
- **Written**: **no** Roll Numbers (they already exist) and **no** Scrutiny. Waiting at Venue.
- **Viva**: no Roll Numbers, but Scrutiny **is** there, and the tail is Final Result → Offer
  Letter → Joining instead of "Send to Next Stage".
- On MCQ, open **Send to Next Stage**: candidates can go to Written **or skip straight to
  Viva**. Interview panels are generated here too.

**`C-2026-02` (Written → Viva)** — opens directly on Scrutiny with 16 candidates loaded.

**Circular workspace** (click a circular in the sidebar) — where the chain itself is set up:
add / remove / reorder stages and change a stage type. Approvals show as a read-only summary
with a **Set up** link, because approvers are configured on the approval step itself. Change a
chain here and every step screen rebuilds itself.

---

## Things worth deliberately breaking

- Click a **grey (locked)** bar on the progress track — it tells you what is blocking it.
- Skip an approval, then reopen it with **Undo skip**.
- **Change this list** or **Take more / fewer candidates** — the steps behind are cleared.
- **Reject** an approval as an approver — the step goes red and needs a revised request.
- Refresh the browser mid-flow — everything is still there.

---

## Where things live

```
index.html                  app shell (sidebar and topbar are filled in by app.js)
assets/css/app.css          theme, step header, action bar, tables
assets/css/print.css        admit card / sheets / offer letter + @media print
assets/js/pipeline.js       THE step engine — which steps exist, what is unlocked,
                            and who is still waiting on each step
assets/js/store.js          localStorage-backed data layer
assets/js/seed.js           the three demo circulars
assets/js/pages/*.js        one file per screen
```

`pipeline.js` is the file to read first. Roll numbers appear only on the first stage, scrutiny
only on a viva, approvals are always shown but never block, and every step reports how many
candidates are still waiting on it. Every flow variant falls out of that one list — nothing
else in the app special-cases MCQ, Written or Viva.
